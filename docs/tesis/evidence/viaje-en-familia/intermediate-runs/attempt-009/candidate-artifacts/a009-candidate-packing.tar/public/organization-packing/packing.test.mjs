import assert from "node:assert/strict";
import test from "node:test";

const moduleUrl = new URL("./packing.mjs", import.meta.url);

function createFakeStorage() {
  const store = new Map();
  return {
    store,
    getItem(key) {
      return store.has(key) ? store.get(key) : null;
    },
    setItem(key, value) {
      store.set(key, String(value));
    },
    removeItem(key) {
      store.delete(key);
    },
    clear() {
      store.clear();
    },
  };
}

function createFakeWindow(localStorage) {
  const listeners = new Map();
  return {
    localStorage,
    addEventListener(type, listener) {
      const set = listeners.get(type) ?? new Set();
      set.add(listener);
      listeners.set(type, set);
    },
    removeEventListener(type, listener) {
      listeners.get(type)?.delete(listener);
    },
    dispatchStorageEvent(key) {
      for (const listener of listeners.get("storage") ?? []) {
        listener({ key, storageArea: localStorage });
      }
    },
  };
}

let cleanup = () => {};

async function loadPackingModule() {
  const storage = createFakeStorage();
  const windowStub = createFakeWindow(storage);

  globalThis.localStorage = storage;
  globalThis.window = windowStub;

  cleanup = () => {
    delete globalThis.localStorage;
    delete globalThis.window;
  };

  return import(`${moduleUrl.href}?t=${Date.now()}`);
}

test.afterEach(() => {
  cleanup();
  cleanup = () => {};
});

test("createPackingState starts empty and reports zero progress", async () => {
  const { createPackingState, PACKING_FILTERS } = await loadPackingModule();
  const store = createPackingState({ namespace: "organization-packing:test-empty" });

  assert.deepEqual(store.items, []);
  assert.deepEqual(store.visibleItems, []);
  assert.deepEqual(store.progress, {
    total: 0,
    packed: 0,
    pending: 0,
    percent: 0,
  });
  assert.equal(store.filter, PACKING_FILTERS.all);

  store.destroy();
});

test("addItem, completeItem, and setFilter update visible items and progress", async () => {
  const { createPackingState, PACKING_FILTERS } = await loadPackingModule();
  const store = createPackingState({ namespace: "organization-packing:test-flow" });
  const observed = [];

  const unsubscribe = store.subscribe((snapshot) => {
    observed.push(snapshot);
  });

  const afterAdd = store.addItem("Campera");
  assert.equal(afterAdd.items.length, 1);
  assert.equal(afterAdd.items[0].label, "Campera");
  assert.equal(afterAdd.items[0].packed, false);
  assert.deepEqual(afterAdd.progress, {
    total: 1,
    packed: 0,
    pending: 1,
    percent: 0,
  });

  const itemId = afterAdd.items[0].id;
  const afterComplete = store.completeItem(itemId);
  assert.equal(afterComplete.items[0].packed, true);
  assert.deepEqual(afterComplete.progress, {
    total: 1,
    packed: 1,
    pending: 0,
    percent: 100,
  });

  const packedOnly = store.setFilter(PACKING_FILTERS.packed);
  assert.equal(packedOnly.filter, PACKING_FILTERS.packed);
  assert.deepEqual(packedOnly.visibleItems, [
    {
      id: itemId,
      label: "Campera",
      packed: true,
    },
  ]);

  const pendingOnly = store.setFilter(PACKING_FILTERS.pending);
  assert.equal(pendingOnly.visibleItems.length, 0);

  assert.ok(observed.length >= 3);

  unsubscribe();
  store.destroy();
});

test("packing state persists through shell storage and syncs across stores", async () => {
  const { createPackingState, normalizePackingState, getPackingProgress } = await loadPackingModule();
  const namespace = "organization-packing:test-sync";

  const primary = createPackingState({ namespace });
  const secondary = createPackingState({ namespace });
  const observed = [];

  const unsubscribe = secondary.subscribe((snapshot) => {
    observed.push(snapshot);
  });

  const first = primary.addItem("Pasaporte");
  const second = primary.addItem("Adaptador universal");
  primary.completeItem(first.items[0].id);

  assert.deepEqual(globalThis.localStorage.getItem(namespace), JSON.stringify(primary.state));
  assert.deepEqual(secondary.items, primary.items);
  assert.equal(secondary.progress.packed, 1);
  assert.equal(secondary.progress.total, 2);
  assert.ok(observed.length > 0);

  const normalized = normalizePackingState({
    items: [{ id: "x", label: "  Bolsa  ", packed: 0 }],
    filter: "packed",
  });
  assert.deepEqual(normalized, {
    items: [{ id: "x", label: "Bolsa", packed: false }],
    filter: "packed",
  });
  assert.deepEqual(getPackingProgress(normalized), {
    total: 1,
    packed: 0,
    pending: 1,
    percent: 0,
  });

  unsubscribe();
  primary.destroy();
  secondary.destroy();
  void second;
});

test("createPackingChecklist exposes the integrated packing organization factory", async () => {
  const { createPackingChecklist, createOrganizationPacking } = await loadPackingModule();
  const namespace = "organization-packing:test-factory";

  const checklist = createPackingChecklist({
    namespace,
    initialState: {
      items: [{ id: "carry-on", label: "Cargador", packed: true }],
      filter: "packed",
    },
  });
  const alias = createOrganizationPacking({ namespace: "organization-packing:test-factory-alias" });

  assert.equal(checklist.namespace, namespace);
  assert.deepEqual(checklist.progress, {
    total: 1,
    packed: 1,
    pending: 0,
    percent: 100,
  });
  assert.equal(checklist.visibleItems.length, 1);
  assert.equal(checklist.element, null);
  assert.equal(typeof alias.addItem, "function");

  checklist.destroy();
  alias.destroy();
});
