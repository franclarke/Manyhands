import { readNamespace, subscribe as subscribeNamespace, writeNamespace } from "../shell/storage.mjs";

export const PACKING_NAMESPACE = "organization-packing";
export const PACKING_FILTERS = Object.freeze({
  all: "all",
  pending: "pending",
  packed: "packed",
});

const DEFAULT_STATE = Object.freeze({
  items: [],
  filter: PACKING_FILTERS.all,
});

let itemIdCounter = 0;

function getDocument() {
  const doc = globalThis.document;
  if (!doc || typeof doc.createElement !== "function") {
    return null;
  }
  return doc;
}

function cloneItem(item) {
  return {
    id: item.id,
    label: item.label,
    packed: Boolean(item.packed),
  };
}

function nextItemId() {
  itemIdCounter += 1;
  const randomPart = typeof crypto !== "undefined" && typeof crypto.randomUUID === "function"
    ? crypto.randomUUID()
    : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  return `packing-item-${itemIdCounter}-${randomPart}`;
}

function normalizeFilter(filter) {
  if (filter === PACKING_FILTERS.all || filter === PACKING_FILTERS.pending || filter === PACKING_FILTERS.packed) {
    return filter;
  }
  return PACKING_FILTERS.all;
}

function normalizeItem(item, fallbackId = nextItemId()) {
  if (!item || typeof item !== "object") {
    return null;
  }

  const label = typeof item.label === "string" ? item.label.trim() : "";
  if (label.length === 0) {
    return null;
  }

  const id = typeof item.id === "string" && item.id.length > 0 ? item.id : fallbackId;

  return {
    id,
    label,
    packed: Boolean(item.packed),
  };
}

function normalizeState(rawState) {
  const input = Array.isArray(rawState)
    ? { items: rawState, filter: DEFAULT_STATE.filter }
    : rawState && typeof rawState === "object"
      ? rawState
      : DEFAULT_STATE;
  const rawItems = Array.isArray(input.items) ? input.items : [];
  const items = [];

  for (const rawItem of rawItems) {
    const item = normalizeItem(rawItem);
    if (item) {
      items.push(item);
    }
  }

  return {
    items,
    filter: normalizeFilter(input.filter),
  };
}

function snapshotState(state) {
  return JSON.stringify({
    filter: state.filter,
    items: state.items.map(cloneItem),
  });
}

function computeProgress(items) {
  const total = items.length;
  const packed = items.filter((item) => item.packed).length;
  const pending = total - packed;
  const percent = total === 0 ? 0 : Math.round((packed / total) * 100);

  return {
    total,
    packed,
    pending,
    percent,
  };
}

function filterItems(items, filter) {
  if (filter === PACKING_FILTERS.packed) {
    return items.filter((item) => item.packed);
  }
  if (filter === PACKING_FILTERS.pending) {
    return items.filter((item) => !item.packed);
  }
  return items.slice();
}

function createStoreListeners() {
  return new Set();
}

export function createPackingStore({
  namespace = PACKING_NAMESPACE,
  initialState = null,
} = {}) {
  const listeners = createStoreListeners();
  let state = normalizeState(initialState ?? readNamespace(namespace));
  let lastSnapshot = snapshotState(state);

  const unsubscribeNamespace = subscribeNamespace(namespace, (value) => {
    const nextState = normalizeState(value);
    const nextSnapshot = snapshotState(nextState);
    if (nextSnapshot === lastSnapshot) {
      return;
    }
    state = nextState;
    lastSnapshot = nextSnapshot;
    for (const listener of listeners) {
      listener(getApi());
    }
  });

  function getApi() {
    return {
      namespace,
      state: snapshot(),
      items: getItems(),
      filter: state.filter,
      progress: getProgress(),
      visibleItems: getVisibleItems(),
    };
  }

  function persist(nextState) {
    state = normalizeState(nextState);
    lastSnapshot = snapshotState(state);
    writeNamespace(namespace, state);
    for (const listener of listeners) {
      listener(getApi());
    }
    return getApi();
  }

  function snapshot() {
    return {
      filter: state.filter,
      items: state.items.map(cloneItem),
    };
  }

  function getItems() {
    return state.items.map(cloneItem);
  }

  function getVisibleItems() {
    return filterItems(getItems(), state.filter);
  }

  function getProgress() {
    return computeProgress(state.items);
  }

  function update(mutator) {
    const nextState = normalizeState(mutator(snapshot()));
    const nextSnapshot = snapshotState(nextState);
    if (nextSnapshot === lastSnapshot) {
      return getApi();
    }
    return persist(nextState);
  }

  function addItem(label) {
    const normalizedLabel = typeof label === "string" ? label.trim() : "";
    if (normalizedLabel.length === 0) {
      throw new TypeError("label must be a non-empty string");
    }

    return update((current) => ({
      ...current,
      items: [
        ...current.items,
        {
          id: nextItemId(),
          label: normalizedLabel,
          packed: false,
        },
      ],
    }));
  }

  function toggleItem(id) {
    if (typeof id !== "string" || id.length === 0) {
      throw new TypeError("id must be a non-empty string");
    }

    return update((current) => ({
      ...current,
      items: current.items.map((item) => (item.id === id ? { ...item, packed: !item.packed } : item)),
    }));
  }

  function completeItem(id) {
    if (typeof id !== "string" || id.length === 0) {
      throw new TypeError("id must be a non-empty string");
    }

    return update((current) => ({
      ...current,
      items: current.items.map((item) => (item.id === id ? { ...item, packed: true } : item)),
    }));
  }

  function setFilter(filter) {
    return update((current) => ({
      ...current,
      filter: normalizeFilter(filter),
    }));
  }

  function removeItem(id) {
    if (typeof id !== "string" || id.length === 0) {
      throw new TypeError("id must be a non-empty string");
    }

    return update((current) => ({
      ...current,
      items: current.items.filter((item) => item.id !== id),
    }));
  }

  function clearPacked() {
    return update((current) => ({
      ...current,
      items: current.items.filter((item) => !item.packed),
    }));
  }

  function subscribe(listener) {
    if (typeof listener !== "function") {
      throw new TypeError("listener must be a function");
    }
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  }

  function destroy() {
    listeners.clear();
    unsubscribeNamespace();
  }

  const api = {
    namespace,
    get state() {
      return snapshot();
    },
    get items() {
      return getItems();
    },
    get filter() {
      return state.filter;
    },
    get progress() {
      return getProgress();
    },
    get visibleItems() {
      return getVisibleItems();
    },
    addItem,
    toggleItem,
    completeItem,
    setFilter,
    removeItem,
    clearPacked,
    subscribe,
    destroy,
    snapshot,
    getItems,
    getVisibleItems,
    getProgress,
    allItems() {
      return getItems();
    },
  };

  return api;
}

function createButton(doc, label, onClick, active = false) {
  const button = doc.createElement("button");
  button.type = "button";
  button.textContent = label;
  button.className = active ? "packing-checklist__filter packing-checklist__filter--active" : "packing-checklist__filter";
  button.addEventListener("click", onClick);
  return button;
}

function createPackingChecklistView(store) {
  const doc = getDocument();
  if (!doc) {
    return null;
  }

  const root = doc.createElement("section");
  root.className = "packing-checklist";
  root.setAttribute("aria-label", "Checklist de equipaje");

  const header = doc.createElement("header");
  header.className = "packing-checklist__header";

  const title = doc.createElement("h1");
  title.textContent = "Checklist de equipaje";
  header.appendChild(title);

  const description = doc.createElement("p");
  description.textContent = "Agrega artículos, márcalos como completados, filtra el equipaje y revisa el progreso total.";
  header.appendChild(description);

  root.appendChild(header);

  const composer = doc.createElement("form");
  composer.className = "packing-checklist__composer";

  const input = doc.createElement("input");
  input.type = "text";
  input.name = "packing-item";
  input.placeholder = "Agregar un artículo";
  input.autocomplete = "off";

  const submit = doc.createElement("button");
  submit.type = "submit";
  submit.textContent = "Agregar";

  composer.appendChild(input);
  composer.appendChild(submit);

  composer.addEventListener("submit", (event) => {
    event.preventDefault();
    const label = input.value.trim();
    if (label.length === 0) {
      return;
    }
    store.addItem(label);
    input.value = "";
  });

  root.appendChild(composer);

  const summary = doc.createElement("section");
  summary.className = "packing-checklist__summary";

  const summaryText = doc.createElement("p");
  summaryText.className = "packing-checklist__summary-text";
  summary.appendChild(summaryText);

  const progress = doc.createElement("progress");
  progress.max = 100;
  progress.value = 0;
  summary.appendChild(progress);

  root.appendChild(summary);

  const filters = doc.createElement("div");
  filters.className = "packing-checklist__filters";
  const filterButtons = new Map();
  for (const [label, filter] of [
    ["Todo", PACKING_FILTERS.all],
    ["Pendiente", PACKING_FILTERS.pending],
    ["Listo", PACKING_FILTERS.packed],
  ]) {
    const button = createButton(doc, label, () => store.setFilter(filter), store.filter === filter);
    filterButtons.set(filter, button);
    filters.appendChild(button);
  }
  root.appendChild(filters);

  const list = doc.createElement("ul");
  list.className = "packing-checklist__list";
  root.appendChild(list);

  const emptyState = doc.createElement("p");
  emptyState.className = "packing-checklist__empty";
  emptyState.textContent = "Todavía no hay artículos cargados.";
  root.appendChild(emptyState);

  function render() {
    const currentItems = store.visibleItems;
    const stats = store.progress;
    summaryText.textContent = `${stats.packed} de ${stats.total} artículos listos`;
    progress.value = stats.percent;

    for (const [filter, button] of filterButtons) {
      button.className = filter === store.filter ? "packing-checklist__filter packing-checklist__filter--active" : "packing-checklist__filter";
      button.setAttribute("aria-pressed", filter === store.filter ? "true" : "false");
    }

    list.replaceChildren();
    emptyState.hidden = currentItems.length > 0;

    for (const item of currentItems) {
      const row = doc.createElement("li");
      row.className = item.packed ? "packing-checklist__item packing-checklist__item--packed" : "packing-checklist__item";

      const label = doc.createElement("span");
      label.textContent = item.label;
      row.appendChild(label);

      const controls = doc.createElement("div");
      controls.className = "packing-checklist__item-controls";

      const toggle = doc.createElement("button");
      toggle.type = "button";
      toggle.textContent = item.packed ? "Desmarcar" : "Completar";
      toggle.addEventListener("click", () => store.toggleItem(item.id));
      controls.appendChild(toggle);

      const remove = doc.createElement("button");
      remove.type = "button";
      remove.textContent = "Quitar";
      remove.addEventListener("click", () => store.removeItem(item.id));
      controls.appendChild(remove);

      row.appendChild(controls);
      list.appendChild(row);
    }
  }

  render();
  const unsubscribe = store.subscribe(render);

  return {
    element: root,
    destroy() {
      unsubscribe();
      store.destroy();
    },
  };
}

export function createPackingChecklist(options = {}) {
  const store = createPackingStore(options);
  const view = createPackingChecklistView(store);

  return {
    namespace: store.namespace,
    get state() {
      return store.state;
    },
    get items() {
      return store.items;
    },
    get filter() {
      return store.filter;
    },
    get progress() {
      return store.progress;
    },
    get visibleItems() {
      return store.visibleItems;
    },
    element: view?.element ?? null,
    addItem: store.addItem,
    toggleItem: store.toggleItem,
    completeItem: store.completeItem,
    setFilter: store.setFilter,
    removeItem: store.removeItem,
    clearPacked: store.clearPacked,
    subscribe: store.subscribe,
    snapshot: store.snapshot,
    getItems: store.getItems,
    getVisibleItems: store.getVisibleItems,
    getProgress: store.getProgress,
    destroy() {
      view?.destroy?.();
      if (!view) {
        store.destroy();
      }
    },
  };
}

export const createOrganizationPacking = createPackingChecklist;
export const createPackingOrganization = createPackingChecklist;
export const createPackingApp = createPackingChecklist;
export const createPackingState = createPackingStore;
export const createPackingView = createPackingChecklistView;

export function getPackingProgress(input = null) {
  const state = normalizeState(input);
  return computeProgress(state.items);
}

export function getPackingVisibleItems(input = null) {
  const state = normalizeState(input);
  return filterItems(state.items.map(cloneItem), state.filter);
}

export function normalizePackingState(input = null) {
  return normalizeState(input);
}

export function getPackingFilters() {
  return { ...PACKING_FILTERS };
}

export default createPackingChecklist;
