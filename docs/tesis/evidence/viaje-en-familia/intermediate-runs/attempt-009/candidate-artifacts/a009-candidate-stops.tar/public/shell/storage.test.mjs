import assert from "node:assert/strict";
import test from "node:test";

const moduleUrl = new URL("./storage.mjs", import.meta.url);

function createFakeStorage() {
  const store = new Map();
  return {
    store,
    getItem(key) {
      return store.has(key) ? store.get(key) : null;
    },
    setItem(key, value) {
      store.set(key, String(value));
    },
    removeItem(key) {
      store.delete(key);
    },
    clear() {
      store.clear();
    },
  };
}

function createFakeWindow(localStorage) {
  const listeners = new Map();
  return {
    localStorage,
    addEventListener(type, listener) {
      const set = listeners.get(type) ?? new Set();
      set.add(listener);
      listeners.set(type, set);
    },
    removeEventListener(type, listener) {
      listeners.get(type)?.delete(listener);
    },
    dispatchStorageEvent(key) {
      for (const listener of listeners.get("storage") ?? []) {
        listener({ key, storageArea: localStorage });
      }
    },
  };
}

let cleanup = () => {};

async function loadStorageModule() {
  const storage = createFakeStorage();
  const windowStub = createFakeWindow(storage);

  globalThis.localStorage = storage;
  globalThis.window = windowStub;

  cleanup = () => {
    delete globalThis.localStorage;
    delete globalThis.window;
  };

  return import(`${moduleUrl.href}?t=${Date.now()}`);
}

test.afterEach(() => {
  cleanup();
  cleanup = () => {};
});

test("writeNamespace persists JSON under the exact namespace key", async () => {
  const { readNamespace, writeNamespace } = await loadStorageModule();
  const namespace = "shell:nav";
  const value = { active: "trips", count: 3 };

  const returned = writeNamespace(namespace, value);

  assert.deepEqual(returned, value);
  assert.equal(globalThis.localStorage.getItem(namespace), JSON.stringify(value));
  assert.deepEqual(readNamespace(namespace), value);
});

test("subscribe receives same-tab writes and storage events", async () => {
  const { subscribe, writeNamespace } = await loadStorageModule();
  const namespace = "shell:state";
  const observed = [];

  const unsubscribe = subscribe(namespace, (value) => {
    observed.push(value);
  });

  writeNamespace(namespace, { step: 1 });
  assert.deepEqual(observed, [{ step: 1 }]);

  globalThis.localStorage.setItem(namespace, JSON.stringify({ step: 2 }));
  globalThis.window.dispatchStorageEvent(namespace);
  assert.deepEqual(observed, [{ step: 1 }, { step: 2 }]);

  unsubscribe();
  writeNamespace(namespace, { step: 3 });
  assert.deepEqual(observed, [{ step: 1 }, { step: 2 }]);
});

test("readNamespace returns null for malformed JSON instead of throwing", async () => {
  const { readNamespace } = await loadStorageModule();
  const namespace = "shell:broken";

  globalThis.localStorage.setItem(namespace, "{not-json");

  assert.equal(readNamespace(namespace), null);
});
