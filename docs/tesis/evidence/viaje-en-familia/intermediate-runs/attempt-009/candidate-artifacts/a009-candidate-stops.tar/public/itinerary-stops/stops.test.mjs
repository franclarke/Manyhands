import assert from "node:assert/strict";
import test from "node:test";

const moduleUrl = new URL("./stops.mjs", import.meta.url);

function createFakeStorage() {
  const store = new Map();
  return {
    store,
    getItem(key) {
      return store.has(key) ? store.get(key) : null;
    },
    setItem(key, value) {
      store.set(key, String(value));
    },
    removeItem(key) {
      store.delete(key);
    },
    clear() {
      store.clear();
    },
  };
}

function createFakeWindow(localStorage) {
  const listeners = new Map();
  return {
    localStorage,
    addEventListener(type, listener) {
      const set = listeners.get(type) ?? new Set();
      set.add(listener);
      listeners.set(type, set);
    },
    removeEventListener(type, listener) {
      listeners.get(type)?.delete(listener);
    },
    dispatchStorageEvent(key) {
      for (const listener of listeners.get("storage") ?? []) {
        listener({ key, storageArea: localStorage });
      }
    },
  };
}

let cleanup = () => {};

async function loadStopsModule() {
  const storage = createFakeStorage();
  const windowStub = createFakeWindow(storage);
  const cryptoStub = {
    randomUUID: (() => {
      let next = 0;
      return () => `uuid-${++next}`;
    })(),
  };

  const descriptors = {
    localStorage: Object.getOwnPropertyDescriptor(globalThis, "localStorage"),
    window: Object.getOwnPropertyDescriptor(globalThis, "window"),
    crypto: Object.getOwnPropertyDescriptor(globalThis, "crypto"),
  };

  Object.defineProperty(globalThis, "localStorage", {
    configurable: true,
    value: storage,
    writable: true,
  });
  Object.defineProperty(globalThis, "window", {
    configurable: true,
    value: windowStub,
    writable: true,
  });
  Object.defineProperty(globalThis, "crypto", {
    configurable: true,
    value: cryptoStub,
    writable: true,
  });

  cleanup = () => {
    for (const [key, descriptor] of Object.entries(descriptors)) {
      if (descriptor) {
        Object.defineProperty(globalThis, key, descriptor);
      } else {
        delete globalThis[key];
      }
    }
  };

  return import(`${moduleUrl.href}?t=${Date.now()}`);
}

test.afterEach(() => {
  cleanup();
  cleanup = () => {};
});

test("createStop persists a new stop with the shared contract shape", async () => {
  const { createStop, listStops } = await loadStopsModule();

  const created = createStop({
    name: "Madrid",
    startDate: "2026-09-01",
    endDate: "2026-09-03",
    description: "Llegada y paseo inicial",
  });

  assert.equal(created.id, "uuid-1");
  assert.deepEqual(created, {
    id: "uuid-1",
    name: "Madrid",
    startDate: "2026-09-01",
    endDate: "2026-09-03",
    description: "Llegada y paseo inicial",
    order: 1,
  });
  assert.deepEqual(listStops(), [created]);
  assert.deepEqual(
    JSON.parse(globalThis.localStorage.getItem("itinerary-stops")),
    [created],
  );
});

test("updateStop edits a stop without changing its order", async () => {
  const { createStop, updateStop, listStops } = await loadStopsModule();

  const first = createStop({
    name: "Madrid",
    startDate: "2026-09-01",
    endDate: "2026-09-03",
    description: "Llegada",
  });
  createStop({
    name: "Toledo",
    startDate: "2026-09-03",
    endDate: "2026-09-04",
    description: "Excursión",
  });

  const updated = updateStop(first.id, {
    name: "Madrid centro",
    description: "Llegada y cena",
  });

  assert.equal(updated.id, first.id);
  assert.equal(updated.order, 1);
  assert.equal(updated.name, "Madrid centro");
  assert.equal(updated.description, "Llegada y cena");
  assert.deepEqual(listStops().map(({ id, name, order }) => ({ id, name, order })), [
    { id: first.id, name: "Madrid centro", order: 1 },
    { id: "uuid-2", name: "Toledo", order: 2 },
  ]);
});

test("removeStop deletes a stop and renumbers the remaining stops", async () => {
  const { createStop, removeStop, listStops } = await loadStopsModule();

  const first = createStop({
    name: "Madrid",
    startDate: "2026-09-01",
    endDate: "2026-09-03",
    description: "Llegada",
  });
  const second = createStop({
    name: "Toledo",
    startDate: "2026-09-03",
    endDate: "2026-09-04",
    description: "Excursión",
  });
  const third = createStop({
    name: "Valencia",
    startDate: "2026-09-04",
    endDate: "2026-09-06",
    description: "Playa",
  });

  const removed = removeStop(second.id);

  assert.deepEqual(removed, second);
  assert.deepEqual(listStops(), [
    { ...first, order: 1 },
    { ...third, order: 2 },
  ]);
});

test("reorderStops accepts an ordered id list and keeps missing stops at the end", async () => {
  const { createStop, reorderStops, listStops } = await loadStopsModule();

  const first = createStop({
    name: "Madrid",
    startDate: "2026-09-01",
    endDate: "2026-09-03",
    description: "Llegada",
  });
  const second = createStop({
    name: "Toledo",
    startDate: "2026-09-03",
    endDate: "2026-09-04",
    description: "Excursión",
  });
  const third = createStop({
    name: "Valencia",
    startDate: "2026-09-04",
    endDate: "2026-09-06",
    description: "Playa",
  });

  const reordered = reorderStops([third.id, first.id]);

  assert.deepEqual(reordered.map(({ id, order }) => ({ id, order })), [
    { id: third.id, order: 1 },
    { id: first.id, order: 2 },
    { id: second.id, order: 3 },
  ]);
  assert.deepEqual(listStops(), reordered);
});
