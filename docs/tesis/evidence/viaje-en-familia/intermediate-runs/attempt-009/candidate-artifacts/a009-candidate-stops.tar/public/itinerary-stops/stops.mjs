import { readNamespace, writeNamespace } from "../shell/storage.mjs";

const STORAGE_NAMESPACE = "itinerary-stops";
const STOP_FIELDS = ["id", "name", "startDate", "endDate", "description", "order"];

let fallbackStopId = 0;

function readRawStops() {
  const value = readNamespace(STORAGE_NAMESPACE);
  if (!Array.isArray(value)) {
    return [];
  }

  return value;
}

function isObject(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function toStringValue(value) {
  return typeof value === "string" ? value : String(value ?? "");
}

function requireTextValue(value, field) {
  const text = toStringValue(value).trim();
  if (!text) {
    throw new TypeError(`${field} must be a non-empty string`);
  }

  return text;
}

function toOrderValue(value) {
  const order = Number(value);
  return Number.isFinite(order) ? order : 0;
}

function cloneStop(stop) {
  return {
    id: stop.id,
    name: stop.name,
    startDate: stop.startDate,
    endDate: stop.endDate,
    description: stop.description,
    order: stop.order,
  };
}

function compareStopsByOrder(left, right) {
  if (left.order !== right.order) {
    return left.order - right.order;
  }

  return left.id.localeCompare(right.id);
}

function normalizeStops(stops) {
  const normalized = [];
  const seen = new Set();

  for (const candidate of Array.isArray(stops) ? stops : []) {
    if (!isObject(candidate)) {
      continue;
    }

    const id = toStringValue(candidate.id).trim();
    if (!id || seen.has(id)) {
      continue;
    }
    seen.add(id);

    normalized.push({
      id,
      name: toStringValue(candidate.name),
      startDate: toStringValue(candidate.startDate),
      endDate: toStringValue(candidate.endDate),
      description: toStringValue(candidate.description),
      order: toOrderValue(candidate.order),
    });
  }

  normalized.sort(compareStopsByOrder);

  return normalized.map((stop, index) => ({
    ...stop,
    order: index + 1,
  }));
}

function persistStops(stops) {
  const normalized = normalizeStops(stops);
  writeNamespace(STORAGE_NAMESPACE, normalized);
  return normalized.map(cloneStop);
}

function nextStopId() {
  if (typeof crypto !== "undefined" && crypto && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }

  fallbackStopId += 1;
  return `stop-${fallbackStopId}`;
}

function resolveStopId(input, fallback) {
  if (typeof input === "string") {
    return input;
  }

  if (isObject(input) && typeof input.id === "string") {
    return input.id;
  }

  if (typeof fallback === "string") {
    return fallback;
  }

  throw new TypeError("stop id must be provided");
}

function resolvePatch(input, maybePatch) {
  if (isObject(input) && maybePatch === undefined) {
    return input;
  }

  if (isObject(maybePatch)) {
    return maybePatch;
  }

  return {};
}

function resolveOrderedIds(input) {
  if (Array.isArray(input)) {
    return input.map((item) => resolveStopId(item));
  }

  if (isObject(input)) {
    if (Array.isArray(input.orderedIds)) {
      return input.orderedIds.map((item) => resolveStopId(item));
    }

    if (Array.isArray(input.ids)) {
      return input.ids.map((item) => resolveStopId(item));
    }

    if (typeof input.id === "string" && typeof input.targetId === "string") {
      const stops = listStops();
      const ids = stops.map((stop) => stop.id);
      const fromIndex = ids.indexOf(input.id);
      const toIndex = ids.indexOf(input.targetId);
      if (fromIndex !== -1 && toIndex !== -1) {
        const next = ids.slice();
        const [moved] = next.splice(fromIndex, 1);
        next.splice(toIndex, 0, moved);
        return next;
      }
    }
  }

  return null;
}

function resolveStopRecord(input) {
  if (!isObject(input)) {
    throw new TypeError("stop must be an object");
  }

  return {
    id: typeof input.id === "string" && input.id.trim() ? input.id.trim() : nextStopId(),
    name: requireTextValue(input.name, "name"),
    startDate: requireTextValue(input.startDate, "startDate"),
    endDate: requireTextValue(input.endDate, "endDate"),
    description: toStringValue(input.description),
  };
}

export function listStops() {
  return normalizeStops(readRawStops()).map(cloneStop);
}

export function createStop(input) {
  const currentStops = listStops();
  const stop = resolveStopRecord(input);
  const created = {
    ...stop,
    order: currentStops.length + 1,
  };

  return persistStops([...currentStops, created]).at(-1) ?? cloneStop(created);
}

export function updateStop(input, maybePatch) {
  const id = resolveStopId(input);
  const patch = resolvePatch(input, maybePatch);
  const currentStops = listStops();
  const index = currentStops.findIndex((stop) => stop.id === id);

  if (index === -1) {
    throw new RangeError(`stop not found: ${id}`);
  }

  const updated = {
    ...currentStops[index],
    ...(typeof patch.name === "undefined" ? {} : { name: requireTextValue(patch.name, "name") }),
    ...(typeof patch.startDate === "undefined" ? {} : { startDate: requireTextValue(patch.startDate, "startDate") }),
    ...(typeof patch.endDate === "undefined" ? {} : { endDate: requireTextValue(patch.endDate, "endDate") }),
    ...(typeof patch.description === "undefined" ? {} : { description: toStringValue(patch.description) }),
    id,
  };

  const nextStops = currentStops.slice();
  nextStops[index] = updated;

  return persistStops(nextStops).find((stop) => stop.id === id) ?? cloneStop(updated);
}

export function removeStop(input) {
  const id = resolveStopId(input);
  const currentStops = listStops();
  const index = currentStops.findIndex((stop) => stop.id === id);

  if (index === -1) {
    throw new RangeError(`stop not found: ${id}`);
  }

  const removed = currentStops[index];
  const nextStops = currentStops.filter((stop) => stop.id !== id);
  persistStops(nextStops);
  return cloneStop(removed);
}

export function reorderStops(input) {
  const orderedIds = resolveOrderedIds(input);
  if (!orderedIds) {
    throw new TypeError("reorderStops requires an ordered list of stop ids");
  }

  const currentStops = listStops();
  const byId = new Map(currentStops.map((stop) => [stop.id, stop]));
  const nextStops = [];
  const used = new Set();

  for (const id of orderedIds) {
    const stop = byId.get(id);
    if (!stop || used.has(id)) {
      continue;
    }
    used.add(id);
    nextStops.push(stop);
  }

  for (const stop of currentStops) {
    if (!used.has(stop.id)) {
      nextStops.push(stop);
    }
  }

  return persistStops(nextStops);
}
