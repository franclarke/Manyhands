const elementClasses = {
  layout: "shell-layout",
  layoutHeader: "shell-layout__header",
  layoutBody: "shell-layout__body",
  layoutMain: "shell-layout__main",
  layoutAside: "shell-layout__aside",
  layoutFooter: "shell-layout__footer",
  section: "shell-section",
  sectionHeader: "shell-section__header",
  sectionBody: "shell-section__body",
  toolbar: "shell-toolbar",
  action: "shell-action",
};

let idCounter = 0;

function getDocument() {
  const doc = globalThis.document;
  if (!doc || typeof doc.createElement !== "function") {
    throw new Error("document is required to build shell layouts");
  }
  return doc;
}

function nextId(prefix) {
  idCounter += 1;
  return `${prefix}-${idCounter}`;
}

function appendValue(target, value) {
  if (value === null || value === undefined || value === false) {
    return;
  }

  const doc = getDocument();

  if (Array.isArray(value)) {
    for (const item of value) {
      appendValue(target, item);
    }
    return;
  }

  if (typeof value === "string" || typeof value === "number") {
    target.appendChild(doc.createTextNode(String(value)));
    return;
  }

  target.appendChild(value);
}

function createActionNode(action) {
  const doc = getDocument();

  if (action && typeof action === "object" && typeof action.nodeType === "number") {
    return action;
  }

  if (action && typeof action === "object") {
    if (action.href) {
      const link = doc.createElement("a");
      link.className = elementClasses.action;
      link.setAttribute("href", action.href);
      link.textContent = action.label ?? action.href;
      if (action.ariaLabel) {
        link.setAttribute("aria-label", action.ariaLabel);
      }
      return link;
    }

    const button = doc.createElement("button");
    button.className = elementClasses.action;
    button.type = action.type ?? "button";
    button.textContent = action.label ?? "";
    if (action.disabled) {
      button.disabled = true;
    }
    if (action.ariaLabel) {
      button.setAttribute("aria-label", action.ariaLabel);
    }
    if (typeof action.onClick === "function") {
      button.addEventListener("click", action.onClick);
    }
    return button;
  }

  const span = doc.createElement("span");
  span.className = elementClasses.action;
  span.textContent = String(action ?? "");
  return span;
}

export function createShellToolbar(actions = [], label = "Shell actions") {
  const doc = getDocument();
  const toolbar = doc.createElement("div");
  toolbar.className = elementClasses.toolbar;
  toolbar.setAttribute("role", "toolbar");
  toolbar.setAttribute("aria-label", label);

  for (const action of actions) {
    appendValue(toolbar, createActionNode(action));
  }

  return toolbar;
}

export function createShellSection({
  title,
  description,
  children = [],
  level = 2,
  actions = [],
  label = title,
} = {}) {
  const doc = getDocument();
  const section = doc.createElement("section");
  section.className = elementClasses.section;

  const headingId = nextId("shell-section-title");
  const descriptionId = description ? nextId("shell-section-description") : null;

  if (headingId) {
    section.setAttribute("aria-labelledby", headingId);
  }
  if (descriptionId) {
    section.setAttribute("aria-describedby", descriptionId);
  }
  if (label && !title) {
    section.setAttribute("aria-label", label);
  }

  const header = doc.createElement("header");
  header.className = elementClasses.sectionHeader;

  const heading = doc.createElement(`h${Math.min(Math.max(level, 1), 6)}`);
  heading.id = headingId;
  heading.textContent = title ?? label ?? "";
  header.appendChild(heading);

  if (description) {
    const copy = doc.createElement("p");
    copy.id = descriptionId;
    copy.textContent = description;
    header.appendChild(copy);
  }

  section.appendChild(header);

  if (actions && actions.length > 0) {
    section.appendChild(createShellToolbar(actions, `${heading.textContent} actions`));
  }

  const body = doc.createElement("div");
  body.className = elementClasses.sectionBody;
  appendValue(body, children);
  section.appendChild(body);

  return section;
}

export function createShellLayout({
  title,
  description,
  actions = [],
  children = [],
  aside = null,
  footer = null,
  label = "Shell",
} = {}) {
  const doc = getDocument();
  const root = doc.createElement("section");
  root.className = elementClasses.layout;

  const titleId = nextId("shell-layout-title");
  const descriptionId = description ? nextId("shell-layout-description") : null;

  root.setAttribute("aria-labelledby", titleId);
  if (descriptionId) {
    root.setAttribute("aria-describedby", descriptionId);
  }

  const header = doc.createElement("header");
  header.className = elementClasses.layoutHeader;

  const headingGroup = doc.createElement("div");
  headingGroup.className = "shell-layout__headline";

  const eyebrow = doc.createElement("p");
  eyebrow.className = "shell-layout__eyebrow";
  eyebrow.textContent = label;
  headingGroup.appendChild(eyebrow);

  const heading = doc.createElement("h1");
  heading.id = titleId;
  heading.textContent = title ?? label;
  headingGroup.appendChild(heading);

  if (description) {
    const copy = doc.createElement("p");
    copy.id = descriptionId;
    copy.className = "shell-layout__description";
    copy.textContent = description;
    headingGroup.appendChild(copy);
  }

  header.appendChild(headingGroup);

  if (actions && actions.length > 0) {
    header.appendChild(createShellToolbar(actions));
  }

  root.appendChild(header);

  const body = doc.createElement("div");
  body.className = elementClasses.layoutBody;

  const main = doc.createElement("main");
  main.className = elementClasses.layoutMain;
  appendValue(main, children);
  body.appendChild(main);

  if (aside) {
    const asideElement = doc.createElement("aside");
    asideElement.className = elementClasses.layoutAside;
    if (typeof aside === "object" && aside && aside.label) {
      asideElement.setAttribute("aria-label", aside.label);
      appendValue(asideElement, aside.content ?? []);
    } else {
      appendValue(asideElement, aside);
    }
    body.appendChild(asideElement);
  }

  root.appendChild(body);

  if (footer) {
    const footerElement = doc.createElement("footer");
    footerElement.className = elementClasses.layoutFooter;
    appendValue(footerElement, footer);
    root.appendChild(footerElement);
  }

  return root;
}

export const shellClasses = Object.freeze(elementClasses);
