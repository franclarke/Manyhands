const listenersByNamespace = new Map();
let storageEventsBound = false;

function getWindowObject() {
  if (typeof window !== "undefined" && window) {
    return window;
  }
  return globalThis.window ?? null;
}

function getStorage() {
  const win = getWindowObject();
  return win?.localStorage ?? globalThis.localStorage ?? null;
}

function assertNamespace(namespace) {
  if (typeof namespace !== "string" || namespace.length === 0) {
    throw new TypeError("namespace must be a non-empty string");
  }
}

function parseStoredValue(namespace, rawValue) {
  if (rawValue === null) {
    return null;
  }

  try {
    return JSON.parse(rawValue);
  } catch {
    return null;
  }
}

function notifyNamespace(namespace, value) {
  const listeners = listenersByNamespace.get(namespace);
  if (!listeners || listeners.size === 0) {
    return;
  }

  for (const listener of listeners) {
    listener(value);
  }
}

function handleStorageEvent(event) {
  if (!event || typeof event.key !== "string") {
    return;
  }

  const namespace = event.key;
  if (!listenersByNamespace.has(namespace)) {
    return;
  }

  notifyNamespace(namespace, readNamespace(namespace));
}

function ensureStorageEvents() {
  if (storageEventsBound) {
    return;
  }

  const win = getWindowObject();
  if (!win || typeof win.addEventListener !== "function") {
    return;
  }

  win.addEventListener("storage", handleStorageEvent);
  storageEventsBound = true;
}

function maybeRemoveStorageEvents() {
  if (listenersByNamespace.size !== 0 || !storageEventsBound) {
    return;
  }

  const win = getWindowObject();
  if (!win || typeof win.removeEventListener !== "function") {
    return;
  }

  win.removeEventListener("storage", handleStorageEvent);
  storageEventsBound = false;
}

export function readNamespace(namespace) {
  assertNamespace(namespace);

  const storage = getStorage();
  if (!storage) {
    return null;
  }

  return parseStoredValue(namespace, storage.getItem(namespace));
}

export function writeNamespace(namespace, value) {
  assertNamespace(namespace);

  const storage = getStorage();
  if (!storage) {
    throw new Error("window.localStorage is not available");
  }

  const serialized = JSON.stringify(value);
  if (typeof serialized !== "string") {
    throw new TypeError("value must be JSON serializable");
  }

  storage.setItem(namespace, serialized);
  notifyNamespace(namespace, value);
  return value;
}

export function subscribe(namespace, listener) {
  assertNamespace(namespace);

  if (typeof listener !== "function") {
    throw new TypeError("listener must be a function");
  }

  let listeners = listenersByNamespace.get(namespace);
  if (!listeners) {
    listeners = new Set();
    listenersByNamespace.set(namespace, listeners);
  }

  listeners.add(listener);
  ensureStorageEvents();

  return () => {
    const currentListeners = listenersByNamespace.get(namespace);
    if (!currentListeners) {
      return;
    }

    currentListeners.delete(listener);
    if (currentListeners.size === 0) {
      listenersByNamespace.delete(namespace);
      maybeRemoveStorageEvents();
    }
  };
}
