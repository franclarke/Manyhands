import assert from "node:assert/strict";
import test from "node:test";

const moduleUrl = new URL("./layout.mjs", import.meta.url);

class FakeNode {
  constructor(nodeType) {
    this.nodeType = nodeType;
    this.childNodes = [];
    this.parentNode = null;
    this._textContent = "";
  }

  appendChild(node) {
    this.childNodes.push(node);
    node.parentNode = this;
    return node;
  }

  addEventListener() {}

  set textContent(value) {
    this._textContent = String(value);
    this.childNodes = [];
  }

  get textContent() {
    if (this.childNodes.length === 0) {
      return this._textContent;
    }

    return this.childNodes.map((node) => node.textContent ?? "").join("");
  }
}

class FakeTextNode extends FakeNode {
  constructor(text) {
    super(3);
    this._textContent = String(text);
  }
}

class FakeElement extends FakeNode {
  constructor(tagName) {
    super(1);
    this.tagName = tagName.toUpperCase();
    this.attributes = new Map();
    this.className = "";
    this.type = "";
    this.disabled = false;
    this.id = "";
    this.eventListeners = new Map();
  }

  setAttribute(name, value) {
    this.attributes.set(name, String(value));
  }

  getAttribute(name) {
    return this.attributes.has(name) ? this.attributes.get(name) : null;
  }

  addEventListener(type, listener) {
    const listeners = this.eventListeners.get(type) ?? new Set();
    listeners.add(listener);
    this.eventListeners.set(type, listeners);
  }
}

class FakeDocument {
  createElement(tagName) {
    return new FakeElement(tagName);
  }

  createTextNode(text) {
    return new FakeTextNode(text);
  }
}

function findFirst(node, predicate) {
  if (predicate(node)) {
    return node;
  }

  for (const child of node.childNodes ?? []) {
    const match = findFirst(child, predicate);
    if (match) {
      return match;
    }
  }

  return null;
}

let cleanup = () => {};

async function loadLayoutModule() {
  globalThis.document = new FakeDocument();
  cleanup = () => {
    delete globalThis.document;
  };

  return import(`${moduleUrl.href}?t=${Date.now()}`);
}

test.afterEach(() => {
  cleanup();
  cleanup = () => {};
});

test("createShellLayout builds an accessible page frame", async () => {
  const { createShellLayout } = await loadLayoutModule();

  const content = globalThis.document.createElement("article");
  content.textContent = "Primary content";

  const layout = createShellLayout({
    title: "Trip planner",
    description: "Reusable frame for the shell areas.",
    actions: [{ label: "Save" }],
    children: [content],
    aside: { label: "Context panel", content: ["Support text"] },
    footer: "Footer note",
  });

  assert.equal(layout.tagName, "SECTION");
  assert.equal(layout.className, "shell-layout");
  assert.equal(layout.getAttribute("aria-labelledby"), layout.childNodes[0].childNodes[0].childNodes[1].id);
  assert.ok(layout.getAttribute("aria-describedby"));

  const main = findFirst(layout, (node) => node.tagName === "MAIN");
  assert.ok(main);
  assert.equal(main.className, "shell-layout__main");
  assert.equal(main.childNodes[0], content);

  const toolbar = findFirst(layout, (node) => node.getAttribute?.("role") === "toolbar");
  assert.ok(toolbar);
  assert.equal(toolbar.getAttribute("aria-label"), "Shell actions");

  const button = findFirst(layout, (node) => node.tagName === "BUTTON");
  assert.ok(button);
  assert.equal(button.textContent, "Save");

  const aside = findFirst(layout, (node) => node.tagName === "ASIDE");
  assert.ok(aside);
  assert.equal(aside.getAttribute("aria-label"), "Context panel");

  const footer = findFirst(layout, (node) => node.tagName === "FOOTER");
  assert.ok(footer);
  assert.equal(footer.textContent, "Footer note");
});

test("createShellSection scopes headings and content accessibly", async () => {
  const { createShellSection } = await loadLayoutModule();

  const section = createShellSection({
    title: "Highlights",
    description: "Area-specific content.",
    level: 3,
    actions: [{ label: "Refresh" }],
    children: ["Body copy"],
  });

  assert.equal(section.tagName, "SECTION");
  assert.equal(section.className, "shell-section");
  assert.ok(section.getAttribute("aria-labelledby"));
  assert.ok(section.getAttribute("aria-describedby"));

  const heading = findFirst(section, (node) => node.tagName === "H3");
  assert.ok(heading);
  assert.equal(heading.textContent, "Highlights");

  const body = findFirst(section, (node) => node.className === "shell-section__body");
  assert.ok(body);
  assert.equal(body.textContent, "Body copy");
});
